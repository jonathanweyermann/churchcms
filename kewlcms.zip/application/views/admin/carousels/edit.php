<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/fileselect.js"></script>
<form method="post" action="<?php echo base_url(); ?>admin/articles/edit/<?php echo $article->id; ?>" enctype="multipart/form-data">
			  <div class="row">
			  <div class="col-md-6">
				<h1>Edit Article</h1>
			  </div>
				<div class="col-md-6">
					<div class="btn-group pull-right">
						<input type="submit" name="submit" class="btn btn-default" value="Save" />
						<a href="<?php echo base_url(); ?>admin/articles" class="btn btn-default">Close</a>
				</div>
			  </div>
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
				  		<li><a href="<?php echo base_url(); ?>admin/dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>admin/articles"><i class="fa fa-pencil"></i> Articles</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Add Article</li>
					</ol>
				</div>  
			</div><!-- /.row -->
				<div class="row">
					<div class="col-lg-12">
						
						<div class="form-group">
							<label>Header 1</label>
							<textarea class="form-control" name="title1" rows="2" value="<?php echo $article->header1; ?>" placeholder="Main title" value=""></textarea>
						</div>
						<div class="form-group">
							<label>Header 2</label>
							<textarea class="form-control" name="title2" rows="4" value="<?php echo $carousel->header2; ?>" placeholder="Description of title" value=""></textarea>
						</div>
						
					
						<div class="form-group">
							<form id="xxx">
								<input class="form-control" type="file" title="choose an image please" name="image" id="image" onchange="pressed()" />
								<label id="fileLabel" for="image"><?php echo $carousel->image ; ?></label>
							</form>
							<button id="reset">Reset file</button>
						</div>
					
					</div>
				</div><!-- /.row -->
			</form>


